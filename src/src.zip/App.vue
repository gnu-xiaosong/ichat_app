<template>
  <div id="q-app" class="fullscreen">
    <router-view />
  </div>
</template>

<script>
export default {
  name: 'App'
}
</script>
